sed_and_awk
===========

A online presentation for sed &amp; awk. You can see [http://dongweiming.github.io/sed_and_awk](http://dongweiming.github.io/sed_and_awk)

How to use
--------

* For site.

You can start a web app with [Flask](https://github.com/mitsuhiko/flask), You can install following this:

```
sudo pip install -r requirements.txt
```

or

```
sudo easy_install flask
```

then

```
sudo python run.py
```

* For html.

If you want direct use browser open it. for example
on  osx.


```
open index.html
```
